#pragma once
class MMRWrapper
{
public:
	MMRWrapper();
	~MMRWrapper();
};

